# Chat by Vue + Webpack

[Live demo](http://coffcer.github.io/vue-chat/)

<img width="600" src="https://github.com/Coffcer/vue-chat/blob/master/intro.jpg">

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build
```
